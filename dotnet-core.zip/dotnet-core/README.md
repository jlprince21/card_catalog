# File Scanner

A .NET Core file scanner. Collects data about files in a directory (file name,
location size, MD5 hash, etc) and stores them in a MariaDB database.

To run:

```
dotnet restore # to get packages
dotnet run
```

License is MIT. See LICENSE.